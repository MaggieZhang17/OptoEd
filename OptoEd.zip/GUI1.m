function varargout = GUI1(varargin)
% GUI1 MATLAB code for GUI1.fig
%      GUI1, by itself, creates a new GUI1 or raises the existing
%      singleton*.
%
%      H = GUI1 returns the handle to a new GUI1 or the handle to
%      the existing singleton*.
%
%      GUI1('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in GUI1.M with the given input arguments.
%
%      GUI1('Property','Value',...) creates a new GUI1 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI1 before GUI1_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to GUI1_OpeningFcn via varargin.
%
%      *See GUI1 Options on GUIDE's Tools menu.  Choose "GUI1 allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help GUI1

% Last Modified by GUIDE v2.5 08-Apr-2022 21:12:31

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
    'gui_Singleton',  gui_Singleton, ...
    'gui_OpeningFcn', @GUI1_OpeningFcn, ...
    'gui_OutputFcn',  @GUI1_OutputFcn, ...
    'gui_LayoutFcn',  [] , ...
    'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before GUI1 is made visible.
function GUI1_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to GUI1 (see VARARGIN)

% Choose default command line output for GUI1
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

load('data.mat'); % ��ȡ������ı���

global mid
mid = 20;  % x1 x2�Գ���


% UIWAIT makes GUI1 wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = GUI1_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on selection change in popupmenu1.
function popupmenu1_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global a_Cds a_CdTe a_GaAs a_Ge a_InGaAs a_Si n_Cds n_CdTe n_GaAs n_Ge n_InGaAs n_Si e_Cds e_CdTe e_GaAs e_Ge e_InGaAs e_Si
global Cds_min Cds_max GaAs_min GaAs_max Ge_min Ge_max Si_min Si_max CdTe_min CdTe_max InGaAs_min InGaAs_max
global R alpha eta
val=get(handles.popupmenu1,'value');

slider1_Callback(hObject, eventdata, handles);
% switch val
%     case 1
%         axes(handles.axes1)
%         cla
%         axes(handles.axes2)
%         cla
%         axes(handles.axes3)
%         cla
%         return;
%     case 2
%         a = a_Cds;
%         n = n_Cds;
%         e = e_Cds;
%         mini = Cds_min;
%         maxi = Cds_max;
%     case 3
%         a = a_CdTe;
%         n = n_CdTe;
%         e = e_CdTe;
%         mini = CdTe_min;
%         maxi = CdTe_max;
%     case 4
%         a = a_GaAs;
%         n = n_GaAs;
%         e = e_GaAs;
%         mini = GaAs_min;
%         maxi = GaAs_max;
%     case 5
%         a = a_Ge;
%         n = n_Ge;
%         e = e_Ge;
%         mini = Ge_min;
%         maxi = Ge_max;
%     case 6
%         a = a_InGaAs;
%         n = n_InGaAs;
%         e = e_InGaAs;
%         mini = InGaAs_min;
%         maxi = InGaAs_max;
%     case 7
%         a = a_Si;
%         n = n_Si;
%         e = e_Si;
%         mini = Si_min;
%         maxi = Si_max;
% end
% axes(handles.axes1)
% cla
% semilogy(a(:, 1), a(:, 2));
% xlim([mini maxi])
% xlabel('Wavelength({\mu}m)', 'fontsi', 10)
% ylabel('\alpha (m^{-1})','fontsi',10);
% axis tight
% alpha = a(1,2);
% 
% axes(handles.axes2)
% cla
% semilogy(n(:, 1), n(:, 2));
% xlim([mini maxi])
% xlabel('Wavelength({\mu}m)', 'fontsi', 10)
% ylabel('n','fontsi',10);
% axis tight
% R = (n(1,2)-1)^2 / (n(1,2)+1)^2;
% 
% axes(handles.axes3)
% cla
% semilogy(e(:, 1), e(:, 2));
% xlim([mini maxi])
% xlabel('Wavelength({\mu}m)', 'fontsi', 10)
% ylabel('\eta','fontsi',10);
% axis tight
% eta = e(1,2);

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu1


% --- Executes during object creation, after setting all properties.
function popupmenu1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function axes1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to axes1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: place code in OpeningFcn to populate axes1


% --- Executes on slider movement.
function slider1_Callback(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global a_Cds a_CdTe a_GaAs a_Ge a_InGaAs a_Si n_Cds n_CdTe n_GaAs n_Ge n_InGaAs n_Si e_Cds e_CdTe e_GaAs e_Ge e_InGaAs e_Si
global Cds_min Cds_max GaAs_min GaAs_max Ge_min Ge_max Si_min Si_max CdTe_min CdTe_max InGaAs_min InGaAs_max
global R alpha eta

val_s = get(handles.slider1, 'value');
val=get(handles.popupmenu1,'value');

switch val
    case 1
        axes(handles.axes1)
        cla
        axes(handles.axes2)
        cla
        axes(handles.axes3)
        cla
        return;
    case 2
        a = a_Cds;
        n = n_Cds;
        e = e_Cds;
        mini = Cds_min;
        maxi = Cds_max;
    case 3
        a = a_CdTe;
        n = n_CdTe;
        e = e_CdTe;
        mini = CdTe_min;
        maxi = CdTe_max;
    case 4
        a = a_GaAs;
        n = n_GaAs;
        e = e_GaAs;
        mini = GaAs_min;
        maxi = GaAs_max;
    case 5
        a = a_Ge;
        n = n_Ge;
        e = e_Ge;
        mini = Ge_min;
        maxi = Ge_max;
    case 6
        a = a_InGaAs;
        n = n_InGaAs;
        e = e_InGaAs;
        mini = InGaAs_min;
        maxi = InGaAs_max;
    case 7
        a = a_Si;
        n = n_Si;
        e = e_Si;
        mini = Si_min;
        maxi = Si_max;
end
axes(handles.axes1)
cla
hold on
semilogy(a(:, 1), a(:, 2));
xlim([mini maxi])
x = a(:,1);
y = a(:,2);
x1 = (maxi-mini)*val_s+mini;
y1 = interp1(x, y, x1, 'linear');
scatter(x1, y1, 100, '.r')
xlabel('Wavelength({\mu}m)', 'fontsi', 10)
ylabel('\alpha (m^{-1})','fontsi',10);
axis tight
hold off
ylim([min(y) (max(y)-min(y))*0.1 + max(y)])
alpha = y1;

axes(handles.axes2)
cla
hold on
semilogy(n(:, 1), n(:, 2));
xlim([mini maxi])
x = n(:,1);
y = n(:,2);
x1 = (maxi-mini)*val_s+mini;
y1 = interp1(x, y, x1, 'linear');
scatter(x1, y1, 100, '.r')
xlabel('Wavelength({\mu}m)', 'fontsi', 10)
ylabel('n','fontsi',10);
axis tight
hold off
ylim([min(y) (max(y)-min(y))*0.1 + max(y)])
R = (y1-1)^2 / (y1+1)^2;

axes(handles.axes3)
cla
hold on
semilogy(e(:, 1), e(:, 2));
xlim([mini maxi])
x = e(:,1);
y = e(:,2);
x1 = (maxi-mini)*val_s+mini;
y1 = interp1(x, y, x1, 'linear');
scatter(x1, y1, 100, '.r')
xlabel('Wavelength({\mu}m)', 'fontsi', 10)
ylabel('\eta','fontsi',10);
axis tight
hold off
ylim([min(y) (max(y)-min(y))*0.1 + max(y)])
eta = y1;

slider6_Callback(hObject, eventdata, handles);
    
% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function slider1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end

% --- Executes during object creation, after setting all properties.
function axes2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to axes2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: place code in OpeningFcn to populate axes2



% --- Executes on slider movement.
function slider6_Callback(hObject, eventdata, handles)
% hObject    handle to slider6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global a_Cds a_CdTe a_GaAs a_Ge a_InGaAs a_Si n_Cds n_CdTe n_GaAs n_Ge n_InGaAs n_Si e_Cds e_CdTe e_GaAs e_Ge e_InGaAs e_Si
global Cds_min Cds_max GaAs_min GaAs_max Ge_min Ge_max Si_min Si_max CdTe_min CdTe_max InGaAs_min InGaAs_max
global x1 x2 mid R alpha eta
val_s = get(handles.slider6, 'value');
x1 = mid - val_s*15;
x2 = mid + val_s*15;

P0 = str2double(get(handles.edit1,'String'));
x = linspace(0, 1000, 1000)*1e-6;
P = (1-R)*P0*exp(-alpha*x);
axes(handles.axes6)
cla
hold on
scatter(0, P0, 100, '.r')
scatter(0, (1-R)*P0, 100, '.r')
plot(x*1e6, P, 'k', 'lineWidth', 1)
plot([x1 x2; x1 x2], [0 0; 2*P0 2*P0], '--b', 'lineWidth', 1)
if P0~= 0
    ylim([0 1.5*P0])
end
temp = find(P>=0.01*P0);
if x(temp(end))*1e6 < x2+10
    lim = x2+10;
else
    lim = x(temp(end))*1e6;
end
xlim([0, lim])
xlabel('Wavelength({\mu}m)')
text(0+lim/50, P0, 'P_0')
text(0+lim/50, (1-R)*P0, '(1-R)P_0')
text(x1+lim/50, P0/2, 'x1')
text(x2+lim/50, P0/2, 'x2')
hold off

axes(handles.axes5)
cla
hold on
patch([x1 x2 x2 x1], [0 0 1 1], [0.5 0.5 0.5], 'faceAlpha', 0.5, 'edgeColor', 'none')
plot([mid, mid], [0, 1], '--k', 'lineWidth', 0.5)
plot([x1, x1], [0, 1], 'b', 'lineWidth', 1)
plot([x2, x2], [0, 1], 'b', 'lineWidth', 1)
text(x1+1, 0.5, 'x1')
text(x2+1, 0.5, 'x2')
xlim([0, lim])
set(gca,'ytick',[],'ycolor','w')
xlabel('Wavelength({\mu}m)')
hold off




val=get(handles.popupmenu1,'value');

switch val
    case 1
        axes(handles.axes1)
        cla
        axes(handles.axes2)
        cla
        axes(handles.axes3)
        cla
        return;
    case 2
        a = a_Cds;
        n = n_Cds;
        e = e_Cds;
        mini = Cds_min;
        maxi = Cds_max;
    case 3
        a = a_CdTe;
        n = n_CdTe;
        e = e_CdTe;
        mini = CdTe_min;
        maxi = CdTe_max;
    case 4
        a = a_GaAs;
        n = n_GaAs;
        e = e_GaAs;
        mini = GaAs_min;
        maxi = GaAs_max;
    case 5
        a = a_Ge;
        n = n_Ge;
        e = e_Ge;
        mini = Ge_min;
        maxi = Ge_max;
    case 6
        a = a_InGaAs;
        n = n_InGaAs;
        e = e_InGaAs;
        mini = InGaAs_min;
        maxi = InGaAs_max;
    case 7
        a = a_Si;
        n = n_Si;
        e = e_Si;
        mini = Si_min;
        maxi = Si_max;
end

lambda = linspace(mini, maxi, 1000);
x = a(:,1);
y = a(:,2);
a1 = interp1(x, y, lambda, 'linear');
x = e(:,1);
y = e(:,2);
eta1 = interp1(x, y, lambda, 'linear');
x = n(:,1);
y = n(:,2);
n1 = interp1(x, y, lambda, 'linear');
R1 = (n1-1).^2 ./ (n1+1).^2;
Iph = lambda.*eta1/(1.24e-6) .* (1-R1)*P0.*(exp(-a1*x1*1e-6) - exp(-a1*x2*1e-6));
g = lambda.*eta1/(1.24e-6);

axes(handles.axes7)
cla
plot(lambda, Iph, 'k')
xlim([mini, maxi])
xlabel('{\lambda}({\mu}m)')
ylabel('I_{ph}(A)')

axes(handles.axes8)
cla
plot(lambda, g, 'k')
xlim([mini, maxi])
xlabel('{\lambda}({\mu}m)')
ylabel('g(V^{-1})')



% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function slider6_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end



function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double


% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit2_Callback(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
popupmenu1_Callback(hObject, eventdata, handles);
% Hints: get(hObject,'String') returns contents of edit2 as text
%        str2double(get(hObject,'String')) returns contents of edit2 as a double


% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
popupmenu1_Callback(hObject, eventdata, handles);
