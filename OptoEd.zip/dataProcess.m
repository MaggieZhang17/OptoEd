clear,clc,close all

global a_Cds a_CdTe a_GaAs a_Ge a_InGaAs a_Si n_Cds n_CdTe n_GaAs n_Ge n_InGaAs n_Si e_Cds e_CdTe e_GaAs e_Ge e_InGaAs e_Si
global Cds_min Cds_max GaAs_min GaAs_max Ge_min Ge_max Si_min Si_max CdTe_min CdTe_max InGaAs_min InGaAs_max
name = 'Cds';
% ��ȡ����
a_Cds = xlsread([name '/��_' name '.csv']);
n_Cds = xlsread([name '/n_' name '.csv']);
e_Cds = xlsread([name '/��_' name '.csv']);
% ���� ����
[~, IA, ~] = unique(a_Cds(:,1));
a_Cds = a_Cds(IA,:);
[~, IA, ~] = unique(n_Cds(:,1));
n_Cds = n_Cds(IA,:);
[~, IA, ~] = unique(e_Cds(:,1));
e_Cds = e_Cds(IA,:);
% ��ȡ���½�
Cds_min = max([a_Cds(1,1) n_Cds(1,1) e_Cds(1,1)]);
Cds_max = min([a_Cds(end,1) n_Cds(end,1) e_Cds(end,1)]);


name = 'GaAs';
% ��ȡ����
a_GaAs = xlsread([name '/��_' name '.csv']);
n_GaAs = xlsread([name '/n_' name '.csv']);
e_GaAs = xlsread([name '/��_' name '.csv']);
% ���� ����
[~, IA, ~] = unique(a_GaAs(:,1));
a_GaAs = a_GaAs(IA,:);
[~, IA, ~] = unique(n_GaAs(:,1));
n_GaAs = n_GaAs(IA,:);
[~, IA, ~] = unique(e_GaAs(:,1));
e_GaAs = e_GaAs(IA,:);
% ��ȡ���½�
GaAs_min = max([a_GaAs(1,1) n_GaAs(1,1) e_GaAs(1,1)]);
GaAs_max = min([a_GaAs(end,1) n_GaAs(end,1) e_GaAs(end,1)]);


name = 'Ge';
% ��ȡ����
a_Ge = xlsread([name '/��_' name '.csv']);
n_Ge = xlsread([name '/n_' name '.csv']);
e_Ge = xlsread([name '/��_' name '.csv']);
% ���� ����
[~, IA, ~] = unique(a_Ge(:,1));
a_Ge = a_Ge(IA,:);
[~, IA, ~] = unique(n_Ge(:,1));
n_Ge = n_Ge(IA,:);
[~, IA, ~] = unique(e_Ge(:,1));
e_Ge = e_Ge(IA,:);
% ��ȡ���½�
Ge_min = max([a_Ge(1,1) n_Ge(1,1) e_Ge(1,1)]);
Ge_max = min([a_Ge(end,1) n_Ge(end,1) e_Ge(end,1)]);

name = 'Si';
% ��ȡ����
a_Si = xlsread([name '/��_' name '.csv']);
n_Si = xlsread([name '/n_' name '.csv']);
e_Si = xlsread([name '/��_' name '.csv']);
% ���� ����
[~, IA, ~] = unique(a_Si(:,1));
a_Si = a_Si(IA,:);
[~, IA, ~] = unique(n_Si(:,1));
n_Si = n_Si(IA,:);
[~, IA, ~] = unique(e_Si(:,1));
e_Si = e_Si(IA,:);
% ��ȡ���½�
Si_min = max([a_Si(1,1) n_Si(1,1) e_Si(1,1)]);
Si_max = min([a_Si(end,1) n_Si(end,1) e_Si(end,1)]);


name = 'CdTe';
% ��ȡ����
a_CdTe = xlsread([name '/��_' name '.csv']);
n_CdTe = xlsread([name '/n_' name '.csv']);
e_CdTe = xlsread([name '/��_' name '.csv']);
% ���� ����
[~, IA, ~] = unique(a_CdTe(:,1));
a_CdTe = a_CdTe(IA,:);
[~, IA, ~] = unique(n_CdTe(:,1));
n_CdTe = n_CdTe(IA,:);
[~, IA, ~] = unique(e_CdTe(:,1));
e_CdTe = e_CdTe(IA,:);
% ��ȡ���½�
CdTe_min = max([a_CdTe(1,1) n_CdTe(1,1) e_CdTe(1,1)]);
CdTe_max = min([a_CdTe(end,1) n_CdTe(end,1) e_CdTe(end,1)]);


name = 'InGaAs';
% ��ȡ����
a_InGaAs = xlsread([name '/��_' name '.csv']);
n_InGaAs = xlsread([name '/n_' name '.csv']);
e_InGaAs = xlsread([name '/��_' name '.csv']);
% ���� ����
[~, IA, ~] = unique(a_InGaAs(:,1));
a_InGaAs = a_InGaAs(IA,:);
[~, IA, ~] = unique(n_InGaAs(:,1));
n_InGaAs = n_InGaAs(IA,:);
[~, IA, ~] = unique(e_InGaAs(:,1));
e_InGaAs = e_InGaAs(IA,:);
% ��ȡ���½�
InGaAs_min = max([a_InGaAs(1,1) n_InGaAs(1,1) e_InGaAs(1,1)]);
InGaAs_max = min([a_InGaAs(end,1) n_InGaAs(end,1) e_InGaAs(end,1)]);

clear IA name
save data.mat